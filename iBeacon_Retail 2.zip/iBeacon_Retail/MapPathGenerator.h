//
//  MapPathGenerator.h
//  iBeacon_Retail
//
//  Created by SHALINI on 4/15/15.
//  Copyright (c) 2015 TAVANT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapPathGenerator : UIView
@property(nonatomic,strong)NSMutableArray *pathList;
@end
