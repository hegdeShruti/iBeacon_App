//
//  CustomHeaderView.m
//  iBeacon_Retail
//
//  Created by shruthi on 10/04/15.
//  Copyright (c) 2015 TAVANT. All rights reserved.
//

#import "CustomHeaderView.h"

@implementation CustomHeaderView


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
