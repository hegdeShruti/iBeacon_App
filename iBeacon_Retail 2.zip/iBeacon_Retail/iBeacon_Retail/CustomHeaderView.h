//
//  CustomHeaderView.h
//  iBeacon_Retail
//
//  Created by shruthi on 10/04/15.
//  Copyright (c) 2015 TAVANT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomHeaderView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *iconImage;

@end
