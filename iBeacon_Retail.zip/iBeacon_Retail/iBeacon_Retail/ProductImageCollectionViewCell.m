//
//  ProductImageCollectionViewCell.m
//  iBeacon_Retail
//
//  Created by tavant_sreejit on 4/7/15.
//  Copyright (c) 2015 TAVANT. All rights reserved.
//

#import "ProductImageCollectionViewCell.h"

@implementation ProductImageCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
