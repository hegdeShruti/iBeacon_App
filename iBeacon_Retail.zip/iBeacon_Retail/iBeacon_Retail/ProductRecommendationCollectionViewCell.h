//
//  ProductRecommendationCollectionViewCell.h
//  iBeacon_Retail
//
//  Created by tavant_sreejit on 4/6/15.
//  Copyright (c) 2015 TAVANT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductRecommendationCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *productImage;

@end
