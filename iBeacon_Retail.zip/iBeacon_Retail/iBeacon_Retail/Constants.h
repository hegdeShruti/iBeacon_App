//
//  Constants.h
//  iBeacon_Retail
//
//  Created by administrator on 18/03/15.
//  Copyright (c) 2015 TAVANT. All rights reserved.
//

#ifndef iBeacon_Retail_Constants_h
#define iBeacon_Retail_Constants_h

#define MENSECTION_MAC @"d8689a077fa1"
#define WOMENSECTION_MAC @"ff11a3858d44"
#define KIDSSECTION_MAC @"e6b0e928fdde"

#endif
