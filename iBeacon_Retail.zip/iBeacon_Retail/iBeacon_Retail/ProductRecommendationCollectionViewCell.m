//
//  ProductRecommendationCollectionViewCell.m
//  iBeacon_Retail
//
//  Created by tavant_sreejit on 4/6/15.
//  Copyright (c) 2015 TAVANT. All rights reserved.
//

#import "ProductRecommendationCollectionViewCell.h"

@implementation ProductRecommendationCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
