//
//  prodCell.m
//  iBeacon_Retail
//
//  Created by shruthi on 02/03/15.
//  Copyright (c) 2015 TAVANT. All rights reserved.
//

#import "prodCell.h"

@implementation prodCell

- (void)awakeFromNib {
    // Initialization code
}

@end
